🌌 Solar System Explorer (NASA + AI)

Features:
- NASA JPL Horizons data
- Date-wise planet positions
- 3D Solar System (Three.js)
- AI Chatbot
- Mobile responsive

Run Backend:
cd backend
npm install
node server.js

Run Frontend:
Open frontend/index.html using Live Server
