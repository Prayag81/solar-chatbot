import { createScene } from "./threeScene.js";

createScene();

async function fetchPosition() {
  const date = document.getElementById("date").value;
  if (!date) return;

  await fetch(`http://localhost:3000/planet-position?planet=earth&date=${date}`);
}

document.getElementById("date").addEventListener("change", fetchPosition);

window.sendChat = async function () {
  const input = document.getElementById("chatInput");
  const messages = document.getElementById("messages");

  messages.innerHTML += `<p><b>You:</b> ${input.value}</p>`;

  const res = await fetch("http://localhost:3000/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message: input.value })
  });

  const data = await res.json();
  messages.innerHTML += `<p><b>Bot:</b> ${data.reply}</p>`;

  input.value = "";
};
