import axios from "axios";

export async function getPlanetVector(planetId, date) {
  const url = "https://ssd.jpl.nasa.gov/api/horizons.api";

  const params = {
    format: "json",
    COMMAND: planetId,
    CENTER: "500@10",
    EPHEM_TYPE: "VECTORS",
    START_TIME: date,
    STOP_TIME: date,
    STEP_SIZE: "1 d"
  };

  const res = await axios.get(url, { params });
  return res.data;
}
