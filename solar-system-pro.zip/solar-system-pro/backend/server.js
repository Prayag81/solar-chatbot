import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { getPlanetVector } from "./horizons.js";
import { askAI } from "./chatbot.js";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const PLANETS = {
  mercury: 199,
  venus: 299,
  earth: 399,
  mars: 499,
  jupiter: 599,
  saturn: 699,
  uranus: 799,
  neptune: 899
};

app.get("/planet-position", async (req, res) => {
  const { planet, date } = req.query;
  const id = PLANETS[planet];

  if (!id) return res.json({ error: "Invalid planet" });

  const data = await getPlanetVector(id, date);
  res.json(data);
});

app.post("/chat", async (req, res) => {
  const reply = await askAI(req.body.message);
  res.json({ reply });
});

app.listen(3000, () =>
  console.log("🚀 Backend running on http://localhost:3000")
);
